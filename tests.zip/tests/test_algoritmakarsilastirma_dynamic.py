import sys
import os
import time
import heapq
import copy
import random
import matplotlib.pyplot as plt
import csv

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from algorithms.a_star import a_star
from algorithms.genetic_algorithm import generate_initial_population, fitness
from algorithms.constraint_solver import csp_assignments_multi
from models.drone import Drone
from models.teslimat import Teslimat
from models.noflyzone import NoFlyZone
from utils.visualizer import plot_routes
from utils.time_utils import is_time_valid, time_to_minutes
from utils.random_generator import generate_random_drones, generate_random_deliveries, generate_random_noflyzones

#DİNAMİK VERİ SETİ:TÜM ALGORİTMALARIN KIYASLANMASI
# === Dinamik (Rastgele) Veri Seti Üret ===
drones_base = generate_random_drones(count=10)
deliveries_base = generate_random_deliveries(count=50)
nfz_list = generate_random_noflyzones(count=5)

# === A* Sadece Testi ===
def test_astar_only():
    drones = copy.deepcopy(drones_base)
    deliveries = copy.deepcopy(deliveries_base)
    success, energy, charging_time = 0, 0, 0
    start = time.time()
    current_time = 540
    routes = []

    for drone in drones:
        for delivery in deliveries:
            if delivery.weight <= drone.max_weight and not delivery.assigned:
                route, e = a_star(drone.start_pos, delivery.pos, delivery.weight, delivery.priority, nfz_list, current_time)
                if route:
                    routes.append(route)
                    if drone.battery - e < 30:
                        charging_time += 20
                        drone.battery = 100
                    else:
                        drone.battery -= e
                    delivery.assigned = True
                    drone.start_pos = delivery.pos
                    success += 1
                    energy += e
                    break

    end = time.time()
    score = success * 100 - energy - charging_time
    return {
        "name": "A*",
        "success": success,
        "energy": round(energy, 2),
        "charging": charging_time,
        "score": round(score, 2),
        "time": end - start,
        "routes": routes
    }

# === CSP + A* Kombinasyonu ===
def test_csp_combined():
    drones = copy.deepcopy(drones_base)
    deliveries = copy.deepcopy(deliveries_base)
    current_time = 540
    success, energy, charging_time = 0, 0, 0
    start = time.time()
    assignments_list = csp_assignments_multi(drones, deliveries, nfz_list, current_time)
    if not assignments_list or len(assignments_list[0]) == 0:
        return {"name": "CSP+A*", "success": 0, "energy": 0, "charging": 0, "score": 0, "time": 0}

    solution = assignments_list[0]
    for drone in drones:
        for delivery_id, drone_id in solution.items():
            if drone.id == drone_id:
                delivery = next((d for d in deliveries if d.id == delivery_id), None)
                if delivery and is_time_valid(current_time, delivery):
                    route, e = a_star(drone.start_pos, delivery.pos, delivery.weight, delivery.priority, nfz_list, current_time)
                    if route:
                        if drone.battery - e < 30:
                            charging_time += 20
                            drone.battery = 100
                        else:
                            drone.battery -= e
                        drone.start_pos = delivery.pos
                        delivery.assigned = True
                        success += 1
                        energy += e
                        break
    end = time.time()
    score = success * 100 - energy - charging_time
    return {
        "name": "CSP+A*",
        "success": success,
        "energy": round(energy, 2),
        "charging": charging_time,
        "score": round(score, 2),
        "time": end - start
    }

# === Genetik Algoritma Testi ===
def test_ga_only():
    drones = copy.deepcopy(drones_base)
    deliveries = copy.deepcopy(deliveries_base)
    start = time.time()

    population = generate_initial_population(drones, deliveries, nfz_list, size=10)
    if not population:
        print("❌ GA: Başlangıç populasyonu boş.")
        return {"name": "GA", "success": 0, "energy": 0, "charging": 0, "score": 0, "time": 0}

    scores = [fitness(ind, drones, deliveries, nfz_list) for ind in population]
    best_index = scores.index(max(scores))
    best_individual = population[best_index]
    best_score = scores[best_index]

    success, energy_total, charging_time = 0, 0, 0
    current_time = 540
    drone_positions = {d.id: d.start_pos for d in drones}
    drone_battery = {d.id: 100 for d in drones}

    for drone_id, delivery_id in best_individual:
        drone = next((d for d in drones if d.id == drone_id), None)
        delivery = next((d for d in deliveries if d.id == delivery_id), None)
        if not drone or not delivery:
            continue
        route, e = a_star(drone_positions[drone_id], delivery.pos, delivery.weight, delivery.priority, nfz_list, current_time)
        if route:
            success += 1
            energy_total += e
            if drone_battery[drone_id] - e < 30:
                charging_time += 20
                drone_battery[drone_id] = 100
            else:
                drone_battery[drone_id] -= e
            drone_positions[drone_id] = delivery.pos

    end = time.time()
    return {
        "name": "GA",
        "success": success,
        "energy": round(energy_total, 2),
        "charging": charging_time,
        "score": round(best_score, 2),
        "time": round(end - start, 2)
    }

# === Ana Çalıştırma ===
if __name__ == "__main__":
    print("🚀 [DİNAMİK] Algoritma Karşılaştırması")
    astar_result = test_astar_only()
    csp_result = test_csp_combined()
    ga_result = test_ga_only()

    results = [astar_result, csp_result, ga_result]

    print("\n📊 Sonuçlar:")
    print("-" * 70)
    print(f"{'Algoritma':<10} | {'Teslimat':<10} | {'Enerji':<10} | {'Şarj(dk)':<10} | {'Skor':<10} | {'Süre(sn)':<10}")
    print("-" * 70)
    for res in results:
        print(f"{res['name']:<10} | {res['success']:<10} | {res['energy']:<10} | {res['charging']:<10} | {res['score']:<10} | {res['time']:<10.2f}")

    plot_routes(drones_base, deliveries_base, nfz_list, show=True)

    with open("algoritma_karsilastirma_DYNAMIC.csv", mode='w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=["Algoritma", "Teslimat", "Enerji", "Şarj(dk)", "Skor", "Süre(sn)"])
        writer.writeheader()
        for row in results:
            writer.writerow({
                "Algoritma": row["name"],
                "Teslimat": row["success"],
                "Enerji": row["energy"],
                "Şarj(dk)": row["charging"],
                "Skor": row["score"],
                "Süre(sn)": round(row["time"], 2)
            })

    print("📁 Sonuçlar başarıyla 'algoritma_karsilastirma_DYNAMIC.csv' dosyasına kaydedildi.")
